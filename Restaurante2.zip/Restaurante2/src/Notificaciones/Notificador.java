package Notificaciones;

public interface Notificador {
    void notificar();
}
