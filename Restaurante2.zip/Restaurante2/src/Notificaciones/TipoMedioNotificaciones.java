package Notificaciones;

public abstract class TipoMedioNotificaciones {
    private String nombreU;
    public TipoMedioNotificaciones(String nombreU){
        this.nombreU=nombreU;
    }

}
