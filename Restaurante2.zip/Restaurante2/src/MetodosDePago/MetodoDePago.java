package MetodosDePago;

public abstract class MetodoDePago {
    String nombre;
    double total;
}
