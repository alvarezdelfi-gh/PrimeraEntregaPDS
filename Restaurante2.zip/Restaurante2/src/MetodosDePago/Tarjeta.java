package MetodosDePago;

import java.util.Date;

public class Tarjeta {
    private String banco;
    private int numero;
    private String tipo;    //debito credito
    private String nombre;
    private String apellido;
    private Date fechaVencimiento;
}
