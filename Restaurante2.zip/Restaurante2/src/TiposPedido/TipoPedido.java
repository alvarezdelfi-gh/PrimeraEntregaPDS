package TiposPedido;

public abstract class TipoPedido {
}
