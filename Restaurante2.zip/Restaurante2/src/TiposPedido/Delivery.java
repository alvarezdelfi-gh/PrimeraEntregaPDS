package TiposPedido;

public class Delivery extends TipoPedido{
}
