package TiposPedido;

public class TakeAway extends TipoPedido{
}
