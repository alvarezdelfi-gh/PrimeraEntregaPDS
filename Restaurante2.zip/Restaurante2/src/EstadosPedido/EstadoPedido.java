package EstadosPedido;

public interface EstadoPedido {
    void cambiar(Pedido pedido);
    String getNombreEstado();
}

//chequeado